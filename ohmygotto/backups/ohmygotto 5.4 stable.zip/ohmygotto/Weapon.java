package com.ohmygotto;

public class Weapon {
    String id;
    int ammo;
    int maxAmmo;
    int level;
    double fireRate;
    double damage;
    double range; // lifespan in seconds

    public Weapon(String id, int ammo, int maxAmmo, double fireRate, double damage, double range) {
        this.id = id;
        this.ammo = ammo;
        this.maxAmmo = maxAmmo;
        this.fireRate = fireRate;
        this.damage = damage;
        this.range = range;
        this.level = 1;
    }

    public void upgrade() {
        level++;
        if (level <= 7) {
            maxAmmo += 2;
            fireRate *= 0.9;
            damage += 1.5;
        } else {
            damage += 1.0;
        }
        ammo = maxAmmo;
    }

    public boolean canFire() {
        return ammo > 0;
    }

    public void reload() {
        ammo = maxAmmo;
    }

    public String getUpgradePreview() {
        return String.format("- Ammo +%d\n- Rate ↑\n- Dmg +%.1f", 2, (level <= 7 ? 1.5 : 1.0));
    }
}