package com.ohmygotto;

import com.almasb.fxgl.dsl.EntityBuilder;
import com.almasb.fxgl.dsl.FXGL;
import com.almasb.fxgl.entity.Entity;
import com.almasb.fxgl.entity.EntityFactory;
import com.almasb.fxgl.entity.SpawnData;
import com.almasb.fxgl.entity.Spawns;
import com.almasb.fxgl.entity.components.CollidableComponent;
import com.almasb.fxgl.entity.components.IrremovableComponent;
import com.ohmygotto.TacticalSurvivors.EntityType;

import javafx.geometry.Point2D;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

public class GameEntityFactory implements EntityFactory {
    
    @Spawns("player")
    public Entity spawnPlayer(SpawnData data) {
        return FXGL.entityBuilder(data)
            .type(EntityType.PLAYER)
            .viewWithBBox(new Rectangle(30, 30, Color.BLUE))
            .with(new CollidableComponent(true))
            .build();
    }
    
    @Spawns("enemy")
    public Entity spawnEnemy(SpawnData data) {
        return FXGL.entityBuilder(data)
            .type(EntityType.ENEMY)
            .viewWithBBox(new Rectangle(25, 25, Color.RED))
            .with(new CollidableComponent(true))
            .build();
    }

    @Spawns("gridLine")
    public Entity spawnGridLine(SpawnData data) {
        // Add null checks and default values
        int width = data.get("width");
        int height = data.get("height");
        
        return FXGL.entityBuilder(data)
            .type(EntityType.GRID_LINE)
            .view(new Rectangle(width, height, Color.rgb(0, 0, 255, 0.3))) // Semi-transparent blue
            .zIndex(-50)
            .with(new IrremovableComponent())
            .build();
    }
    
    @Spawns("weapon")
    public Entity spawnWeapon(SpawnData data) {
        String weaponType = data.get("weaponType");
        Point2D direction = data.hasKey("direction") ? data.get("direction") : null;
        double speed = data.hasKey("speed") ? data.get("speed") : 0;
    
        EntityBuilder weapon = FXGL.entityBuilder(data)
            .type(TacticalSurvivors.EntityType.WEAPON)
            .with(new CollidableComponent(true))
            .with("weaponType", weaponType);
    
        switch (weaponType) {
            case "Pistol":
                weapon.viewWithBBox(new Rectangle(10, 5, Color.YELLOW));
                break;
            case "Shotgun":
                weapon.viewWithBBox(new Rectangle(8, 8, Color.ORANGE));
                break;
            case "Assault Rifle":
                weapon.viewWithBBox(new Rectangle(8, 4, Color.LIGHTYELLOW));
                break;
            case "Sniper Rifle":
                weapon.viewWithBBox(new Rectangle(15, 3, Color.WHITESMOKE));
                break;
            case "Grenade":
                weapon.viewWithBBox(new Rectangle(12, 12, Color.DARKGREEN));
                break;
            // case "Knife":
            //     weapon.viewWithBBox(new Rectangle(15, 5, Color.SILVER));
            //     break;
            // case "Mine":
            //     weapon.viewWithBBox(new Rectangle(20, 20, Color.DARKRED));
            //     break;
            case "Flame Thrower":
                weapon.viewWithBBox(new Rectangle(30, 15, Color.ORANGERED));
                break;
            case "Rocket Launcher":
                weapon.viewWithBBox(new Rectangle(20, 8, Color.DARKGRAY));
                break;

            
            default:
                weapon.viewWithBBox(new Rectangle(10, 10, Color.WHITE));
        }
    
        if (direction != null) {
            Entity projectileEntity = weapon.build();
            projectileEntity.addComponent(new ProjectileComponent(direction, speed));
        
            // Despawn fallback
            FXGL.runOnce(() -> {
                if (projectileEntity.isActive()) {
                    projectileEntity.removeFromWorld();
                    System.out.println("Despawning: " + projectileEntity);
                }
            }, Duration.seconds(3)); // lifespan
        
            return projectileEntity;
        }
        
    
        if (data.hasKey("lifespan")) {
            double lifespan = data.get("lifespan");
            Entity builtWeapon = weapon.build();
            FXGL.runOnce(() -> {
                if (builtWeapon.isActive()) builtWeapon.removeFromWorld();
            }, Duration.seconds(lifespan));
            return builtWeapon;
        }
    
        return weapon.build();
    }
    
    
    @Spawns("experience")
    public Entity spawnExperience(SpawnData data) {
        return FXGL.entityBuilder(data)
            .type(TacticalSurvivors.EntityType.EXPERIENCE)
            .viewWithBBox(new Rectangle(10, 10, Color.GREEN))
            .with(new CollidableComponent(true))
            .build();
    }
    
    @Spawns("border")
    public Entity spawnBorder(SpawnData data) {
        int width = data.get("width");
        int height = data.get("height");
        
        return FXGL.entityBuilder(data)
            .type(TacticalSurvivors.EntityType.BORDER)
            .viewWithBBox(new Rectangle(width, height, Color.DARKRED))
            .with(new CollidableComponent(true))
            .build();
    }
}