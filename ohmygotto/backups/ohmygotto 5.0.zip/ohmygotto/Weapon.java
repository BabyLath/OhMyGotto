package com.ohmygotto;

public class Weapon {
    String id;
    int ammo;
    int maxAmmo;
    int level;
    double fireRate; // milliseconds between shots
    double damage;

    public Weapon(String id, int ammo, int maxAmmo, double fireRate, double damage) {
        this.id = id;
        this.ammo = ammo;
        this.maxAmmo = maxAmmo;
        this.fireRate = fireRate;
        this.damage = damage;
        this.level = 1;
    }

    public void upgrade() {
        level++;
        if (level <= 7) {
            maxAmmo += 2;
            fireRate *= 0.9;
            damage += 1.5;
        } else {
            damage += 1.0;
        }
        ammo = maxAmmo;
    }

    public void reload() {
        ammo = maxAmmo;
    }

    public boolean canFire() {
        return ammo > 0;
    }

    public String getUpgradePreview() {
        return String.format("+Ammo, +Rate, +Dmg (Lv %d → %d)", level, Math.min(level+1, 8));
    }
}
