package com.ohmygotto;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.almasb.fxgl.app.GameApplication;
import com.almasb.fxgl.app.GameSettings;
import com.almasb.fxgl.dsl.FXGL;
import com.almasb.fxgl.entity.Entity;
import com.almasb.fxgl.entity.SpawnData;
import com.almasb.fxgl.entity.components.IrremovableComponent;
import com.almasb.fxgl.input.UserAction;
import com.almasb.fxgl.physics.CollisionHandler;
import com.almasb.fxgl.ui.ProgressBar;

import javafx.geometry.Point2D;
import javafx.scene.input.KeyCode;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.util.Duration;

public class TacticalSurvivors extends GameApplication {
    // Game constants
    private static final int WIDTH = 1024;
    private static final int HEIGHT = 768;
    private static final int WORLD_WIDTH = WIDTH * 3;
    private static final int WORLD_HEIGHT = HEIGHT * 3;
    private static final double PLAYER_SPEED = 200;
    private static final int MAX_PLAYER_HP = 3;
    private static final int ENEMY_SPAWN_INTERVAL = 10; // seconds
    private static final int LEVEL_UP_THRESHOLD = 10; // enemies killed to level up

    // Game variables
    private Entity player;
    private boolean isGameOver = false;
    private int playerLevel = 1;
    private int enemiesKilled = 0;
    private int xpToNextLevel = LEVEL_UP_THRESHOLD;
    private Random random = new Random();
    private List<String> availableWeapons = new ArrayList<>();
    private List<String> activeWeapons = new ArrayList<>();
    private ProgressBar xpBar;
    private Text hpText;
    private Text levelText;
    private Text killText;

    // Enum for game entity types
    public enum EntityType {
        PLAYER, ENEMY, WEAPON, GRID_LINE, EXPERIENCE, BORDER
    }

    @Override
    protected void initSettings(GameSettings settings) {
        settings.setWidth(WIDTH);
        settings.setHeight(HEIGHT);
        settings.setTitle("Tactical Survivors");
        settings.setVersion("1.0");
        settings.setManualResizeEnabled(false);
        settings.setPreserveResizeRatio(true);
        settings.setAppIcon("player.png"); // You'd need to add this resource
    }

    @Override
    protected void initGame() {
        try {
            // 1. First initialize the factory with proper access
            GameEntityFactory factory = new GameEntityFactory();
            FXGL.getGameWorld().addEntityFactory(factory);
    
            // 2. Create minimal viable entities first
            createEssentialBackground();
            
            // 3. Spawn player
            player = FXGL.spawn("player", WORLD_WIDTH / 2.0, WORLD_HEIGHT / 2.0);
            
            // 4. Set up viewport
            initViewport();
            
            // 5. Schedule delayed initialization for non-critical systems
            FXGL.runOnce(() -> {
                initWeapons();
                startEnemySpawner();
                createFullGridBackground();
            }, Duration.seconds(0.1));
            
        } catch (Exception e) {
            System.err.println("CRITICAL: Game initialization failed");
            e.printStackTrace();
            throw new RuntimeException("Game initialization failed", e);
        }
    }
    
    private void createEssentialBackground() {
        // Just a simple black background first
        Rectangle bg = new Rectangle(WORLD_WIDTH, WORLD_HEIGHT, Color.BLACK);
        FXGL.entityBuilder()
            .at(0, 0)
            .view(bg)
            .zIndex(-100)
            .with(new IrremovableComponent())
            .buildAndAttach();
    }
    
    private void initViewport() {
        FXGL.getGameScene().getViewport().setBounds(0, 0, WORLD_WIDTH, WORLD_HEIGHT);
        FXGL.getGameScene().getViewport().bindToEntity(player, WIDTH / 2.0, HEIGHT / 2.0);
        FXGL.getGameScene().getViewport().setLazy(true);
    }
    
    private void startEnemySpawner() {
        FXGL.run(() -> spawnEnemy(), Duration.seconds(ENEMY_SPAWN_INTERVAL));
    }
    
    private void createFullGridBackground() {
        int gridSize = 100;
        for (int x = 0; x <= WORLD_WIDTH; x += gridSize) {
            // For vertical lines (width=1, height=WORLD_HEIGHT)
            FXGL.spawn("gridLine", 
                new SpawnData(x, 0)
                    .put("width", 1)
                    .put("height", WORLD_HEIGHT)
            );
        }
        for (int y = 0; y <= WORLD_HEIGHT; y += gridSize) {
            // For horizontal lines (width=WORLD_WIDTH, height=1)
            FXGL.spawn("gridLine",
                new SpawnData(0, y)
                    .put("width", WORLD_WIDTH)
                    .put("height", 1)
            );
        }
    }

    private void initWeapons() {
        // Military-themed weapons
        availableWeapons.add("Pistol");      // Basic weapon, average damage and rate
        availableWeapons.add("Shotgun");     // High damage, low rate, short range
        availableWeapons.add("Assault Rifle"); // Medium damage, high rate
        availableWeapons.add("Sniper Rifle"); // Very high damage, very low rate, long range
        availableWeapons.add("Grenade");     // Area damage, low rate
        availableWeapons.add("Knife");       // Melee, high damage, needs to be close
        availableWeapons.add("Mine");        // Placed, detonates when enemies are close
        availableWeapons.add("Flame Thrower"); // Continuous damage over time
        availableWeapons.add("Rocket Launcher"); // Massive area damage, very low rate
        availableWeapons.add("Poison Gas");  // Area damage over time
        
        // Start with pistol
        activeWeapons.add("Pistol");
    }

    private void createSimpleBackground() {
        // Basic background first
        Rectangle background = new Rectangle(WORLD_WIDTH, WORLD_HEIGHT, Color.BLACK);
        FXGL.entityBuilder()
            .at(0, 0)
            .view(background)
            .zIndex(-100)
            .with(new IrremovableComponent())
            .buildAndAttach();
    
        // Simple grid - add complex grid later after initialization
        for (int x = 0; x <= WORLD_WIDTH; x += 200) {
            FXGL.spawn("gridLine", x, 0, 1);
        }
        for (int y = 0; y <= WORLD_HEIGHT; y += 200) {
            FXGL.spawn("gridLine", 0, y, WORLD_WIDTH);
        }
    }

    private void createGridBackground() {
        try {
            // Create black background
            Rectangle background = new Rectangle(WORLD_WIDTH, WORLD_HEIGHT, Color.BLACK);
            Entity bg = FXGL.entityBuilder()
                    .at(0, 0)
                    .view(background)
                    .zIndex(-100)
                    .with(new IrremovableComponent())
                    .build();
            FXGL.getGameWorld().addEntity(bg);
    
            // Create blue grid lines
            int gridSize = 100;
            for (int x = 0; x <= WORLD_WIDTH; x += gridSize) {
                FXGL.spawn("gridLine", x, 0, 1);
            }
            for (int y = 0; y <= WORLD_HEIGHT; y += gridSize) {
                FXGL.spawn("gridLine", 0, y, WORLD_WIDTH);
            }
        } catch (Exception e) {
            System.err.println("Failed to create background: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Background creation failed", e);
        }
    }

    private void createWorldBoundaries() {
        // Top
        FXGL.spawn("border", 0, 0, WORLD_WIDTH);
        // Bottom
        FXGL.spawn("border", 0, WORLD_HEIGHT - 10, WORLD_WIDTH);
        // Left
        FXGL.spawn("border", 0, 0, 10);
        // Right
        FXGL.spawn("border", WORLD_WIDTH - 10, 0, 10);
    }

    @Override
    protected void initPhysics() {
        // Collision between player and enemy
        FXGL.getPhysicsWorld().addCollisionHandler(new CollisionHandler(EntityType.PLAYER, EntityType.ENEMY) {
            @Override
            protected void onCollisionBegin(Entity player, Entity enemy) {
                if (isGameOver) return;
                
                int currentHp = FXGL.geti("playerHp");
                if (currentHp > 1) {
                    FXGL.inc("playerHp", -1);
                    enemy.removeFromWorld();
                    FXGL.play("hurt.wav"); // Add sound effect
                    updateHpText();
                } else {
                    gameOver();
                }
            }
        });

        // Collision between weapon and enemy
        FXGL.getPhysicsWorld().addCollisionHandler(new CollisionHandler(EntityType.WEAPON, EntityType.ENEMY) {
            @Override
            protected void onCollisionBegin(Entity weapon, Entity enemy) {
                if (isGameOver) return;
                
                enemy.removeFromWorld();
                if (weapon.getString("weaponType").equals("Grenade") || 
                    weapon.getString("weaponType").equals("Rocket Launcher")) {
                    // For area weapons, don't remove on collision
                    // Instead, handle the explosion effect
                    createExplosion(weapon.getPosition());
                } else if (!weapon.getString("weaponType").equals("Poison Gas") && 
                           !weapon.getString("weaponType").equals("Flame Thrower")) {
                    // For regular projectiles, remove on hit
                    weapon.removeFromWorld();
                }
                
                // Spawn XP point
                FXGL.spawn("experience", enemy.getX(), enemy.getY());
                
                // Increase kill count
                enemiesKilled++;
                FXGL.inc("killCount", 1);
                updateKillText();
                
                // Check for level up
                checkLevelUp();
            }
        });

        // Collision between player and experience
        FXGL.getPhysicsWorld().addCollisionHandler(new CollisionHandler(EntityType.PLAYER, EntityType.EXPERIENCE) {
            @Override
            protected void onCollisionBegin(Entity player, Entity experience) {
                experience.removeFromWorld();
                FXGL.inc("playerXp", 1);
                updateXpBar();
                
                // Check for level up
                checkLevelUp();
            }
        });

        // Collision between player and border
        FXGL.getPhysicsWorld().addCollisionHandler(new CollisionHandler(EntityType.PLAYER, EntityType.BORDER) {
            @Override
            protected void onCollisionBegin(Entity player, Entity border) {
                // Push player away from border
                Point2D center = new Point2D(WORLD_WIDTH/2, WORLD_HEIGHT/2);
                Point2D direction = center.subtract(player.getPosition()).normalize().multiply(10);
                player.translate(direction);
            }
        });
    }

    private void checkLevelUp() {
        int currentXp = FXGL.geti("playerXp");
        
        if (currentXp >= xpToNextLevel) {
            levelUp();
        }
    }

    private void levelUp() {
        playerLevel++;
        FXGL.set("playerXp", 0);
        xpToNextLevel = LEVEL_UP_THRESHOLD * playerLevel;
        
        FXGL.play("levelup.wav"); // Add sound effect
        updateLevelText();
        updateXpBar();
        
        // Show weapon selection UI
        showWeaponSelection();
    }

    private boolean isGamePaused = false;

    private void showWeaponSelection() {
        try {
            isGamePaused = true;
    
            String newWeapon = getRandomUnownedWeapon();
            if (newWeapon != null) {
                activeWeapons.add(newWeapon);
                FXGL.getNotificationService().pushNotification("New weapon acquired: " + newWeapon);
            }
    
            // Resume game after 1 second without freezing FXGL timers
            FXGL.runOnce(() -> isGamePaused = false, Duration.seconds(1));
    
        } catch (Exception e) {
            System.err.println("Error during weapon selection: " + e.getMessage());
            e.printStackTrace();
            isGamePaused = false;
        }
    }
    
    
    
    private String getRandomUnownedWeapon() {
        try {
            List<String> unownedWeapons = new ArrayList<>(availableWeapons);
            unownedWeapons.removeAll(activeWeapons);
            
            if (unownedWeapons.isEmpty()) {
                return null;
            }
            
            return unownedWeapons.get(random.nextInt(unownedWeapons.size()));
        } catch (Exception e) {
            System.err.println("Error getting random weapon: " + e.getMessage());
            return null;
        }
    }

    private void createExplosion(Point2D position) {
        Entity explosion = FXGL.entityBuilder()
                .at(position)
                .viewWithBBox(new Rectangle(100, 100, Color.ORANGE))
                .with("explosionTimer", 0.5) // duration in seconds
                .buildAndAttach();
        
        FXGL.runOnce(() -> explosion.removeFromWorld(), Duration.seconds(0.5));
    }

    private void updateHpText() {
        hpText.setText("HP: " + FXGL.geti("playerHp") + "/" + MAX_PLAYER_HP);
    }

    private void updateLevelText() {
        levelText.setText("Level: " + playerLevel);
    }

    private void updateKillText() {
        killText.setText("Kills: " + FXGL.geti("killCount"));
    }

    private void updateXpBar() {
        int currentXp = FXGL.geti("playerXp");
        xpBar.setCurrentValue(currentXp);
        xpBar.setMaxValue(xpToNextLevel);
    }

    @Override
    protected void initInput() {
        // Movement controls
        FXGL.onKey(KeyCode.W, () -> movePlayer(0, -1));
        FXGL.onKey(KeyCode.S, () -> movePlayer(0, 1));
        FXGL.onKey(KeyCode.A, () -> movePlayer(-1, 0));
        FXGL.onKey(KeyCode.D, () -> movePlayer(1, 0));
        
        // Attack button
        FXGL.getInput().addAction(new UserAction("Attack") {
            @Override
            protected void onActionBegin() {
                if (!isGameOver) {
                    fireActiveWeapons();
                }
            }
        }, KeyCode.SPACE);
    }

    private void movePlayer(double dx, double dy) {
        if (isGameOver) return;
        
        // Normalize diagonal movement
        if (dx != 0 && dy != 0) {
            dx *= 0.7071; // 1/sqrt(2)
            dy *= 0.7071;
        }
        
        player.translate(dx * PLAYER_SPEED * FXGL.tpf(), dy * PLAYER_SPEED * FXGL.tpf());
    }

    private void fireActiveWeapons() {
        for (String weapon : activeWeapons) {
            fireWeapon(weapon);
        }
    }

    private void fireWeapon(String weaponType) {
        Point2D playerPosition = player.getPosition();
        
        // Aim at mouse cursor
        Point2D mousePosition = FXGL.getInput().getMousePositionWorld();
        Point2D direction = mousePosition.subtract(playerPosition).normalize();

        
        // Different weapon behaviors
        switch (weaponType) {
            case "Pistol":
                spawnProjectile(playerPosition, direction, "Pistol", 10, 500);
                break;
            case "Shotgun":
                // Spread multiple projectiles
                for (int i = -2; i <= 2; i++) {
                    double angle = Math.atan2(direction.getY(), direction.getX()) + Math.toRadians(i * 10);
                    Point2D spreadDir = new Point2D(Math.cos(angle), Math.sin(angle));
                    spawnProjectile(playerPosition, spreadDir, "Shotgun", 15, 400);
                }
                break;
            case "Assault Rifle":
                // Higher fire rate (handled by game timer elsewhere)
                spawnProjectile(playerPosition, direction, "Assault Rifle", 8, 600);
                break;
            case "Sniper Rifle":
                spawnProjectile(playerPosition, direction, "Sniper Rifle", 30, 1000);
                break;
            case "Grenade":
                spawnProjectile(playerPosition, direction, "Grenade", 40, 200);
                break;
            case "Knife":
                // Short range but high damage
                spawnProjectile(playerPosition, direction, "Knife", 25, 100);
                break;
            case "Mine":
                // Plant at player position
                FXGL.spawn("weapon", new SpawnData(playerPosition.getX(), playerPosition.getY())
                    .put("weaponType", "Mine")
                    .put("lifespan", 10.0));
                break;
            case "Flame Thrower":
                // Short range continuous damage
                spawnProjectile(playerPosition, direction, "Flame Thrower", 5, 150);
                break;
            case "Rocket Launcher":
                spawnProjectile(playerPosition, direction, "Rocket Launcher", 50, 300);
                break;
            case "Poison Gas":
                FXGL.spawn("weapon", new SpawnData(playerPosition.getX(), playerPosition.getY())
                    .put("weaponType", "Poison Gas")
                    .put("lifespan", 5.0));
                break;
        }
    }

    private Entity findNearestEnemy() {
        List<Entity> enemies = FXGL.getGameWorld().getEntitiesByType(EntityType.ENEMY);
        
        if (enemies.isEmpty()) {
            return null;
        }
        
        Entity nearest = null;
        double minDistance = Double.MAX_VALUE;
        Point2D playerPos = player.getPosition();
        
        for (Entity enemy : enemies) {
            double distance = enemy.getPosition().distance(playerPos);
            if (distance < minDistance) {
                minDistance = distance;
                nearest = enemy;
            }
        }
        
        return nearest;
    }

    private void spawnProjectile(Point2D position, Point2D direction, String weaponType, int damage, double speed) {
        FXGL.spawn("weapon", new SpawnData(position.getX(), position.getY())
            .put("direction", direction)
            .put("speed", speed)
            .put("weaponType", weaponType)
            .put("damage", damage));
    }

    private void spawnEnemy() {
        if (isGameOver) return;
        //if (isGameOver || isGamePaused) return;
        
        // Get player position
        Point2D playerPos = player.getPosition();
        
        // Spawn enemy outside screen but inside world bounds
        double spawnDistance = 800;
        double angle = random.nextDouble() * 360;
        double x = playerPos.getX() + spawnDistance * Math.cos(Math.toRadians(angle));
        double y = playerPos.getY() + spawnDistance * Math.sin(Math.toRadians(angle));
        
        // Keep within world bounds
        x = Math.max(50, Math.min(WORLD_WIDTH - 50, x));
        y = Math.max(50, Math.min(WORLD_HEIGHT - 50, y));
        
        // Spawn enemy
        FXGL.spawn("enemy", x, y);
        
        // Schedule next spawn
        FXGL.run(() -> spawnEnemy(), Duration.seconds(ENEMY_SPAWN_INTERVAL));
    }

    @Override
    protected void initGameVars(Map<String, Object> vars) {
        vars.put("playerHp", MAX_PLAYER_HP);
        vars.put("playerXp", 0);
        vars.put("killCount", 0);
    }

    @Override
    protected void initUI() {
        // Create UI elements
        hpText = FXGL.getUIFactoryService().newText("HP: " + MAX_PLAYER_HP + "/" + MAX_PLAYER_HP, Color.WHITE, 24);
        levelText = FXGL.getUIFactoryService().newText("Level: " + playerLevel, Color.WHITE, 24);
        killText = FXGL.getUIFactoryService().newText("Kills: 0", Color.WHITE, 24);
        
        // Position UI elements
        hpText.setTranslateX(20);
        hpText.setTranslateY(40);
        levelText.setTranslateX(20);
        levelText.setTranslateY(70);
        killText.setTranslateX(20);
        killText.setTranslateY(100);
        
        // Create XP bar
        xpBar = new ProgressBar(false);
        xpBar.setFill(Color.GREEN);
        xpBar.setBackgroundFill(Color.DARKGRAY);
        xpBar.setMinValue(0);
        xpBar.setMaxValue(LEVEL_UP_THRESHOLD);
        xpBar.setCurrentValue(0);
        xpBar.setWidth(200);
        xpBar.setHeight(15);
        xpBar.setTranslateX(WIDTH - 220);
        xpBar.setTranslateY(20);
        
        Text xpLabel = FXGL.getUIFactoryService().newText("XP", Color.WHITE, 18);
        xpLabel.setTranslateX(WIDTH - 250);
        xpLabel.setTranslateY(32);
        
        // Add UI elements to scene
        FXGL.addUINode(hpText);
        FXGL.addUINode(levelText);
        FXGL.addUINode(killText);
        FXGL.addUINode(xpBar);
        FXGL.addUINode(xpLabel);
    }

    private void gameOver() {
        isGameOver = true;
        FXGL.play("gameover.wav"); // Add sound effect
        
        Text gameOverText = FXGL.getUIFactoryService().newText("GAME OVER", Color.RED, 72);
        gameOverText.setTranslateX(WIDTH / 2.0 - 180);
        gameOverText.setTranslateY(HEIGHT / 2.0);
        
        Text finalScoreText = FXGL.getUIFactoryService().newText(
            "Survived to Level: " + playerLevel + "\nEnemies Killed: " + FXGL.geti("killCount"), 
            Color.WHITE, 36
        );
        finalScoreText.setTranslateX(WIDTH / 2.0 - 150);
        finalScoreText.setTranslateY(HEIGHT / 2.0 + 100);
        
        FXGL.addUINode(gameOverText);
        FXGL.addUINode(finalScoreText);
    }

    @Override
    protected void onUpdate(double tpf) {
        if (isGameOver || isGamePaused) return;

        
        // Auto-firing weapons at intervals
        for (String weapon : activeWeapons) {
            fireWeapon(weapon);
        }
        
        // Update enemies to move toward player
        List<Entity> enemies = FXGL.getGameWorld().getEntitiesByType(EntityType.ENEMY);
        Point2D playerPos = player.getPosition();
        
        for (Entity enemy : enemies) {
            Point2D direction = playerPos.subtract(enemy.getPosition()).normalize();
            double speed = 100 + (playerLevel * 5); // Enemies get faster as levels increase
            enemy.translate(direction.multiply(speed * tpf));
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}

// Component for projectile movement
class ProjectileComponent extends com.almasb.fxgl.entity.component.Component {
    private Point2D direction;
    private double speed;
    
    public ProjectileComponent(Point2D direction, double speed) {
        this.direction = direction;
        this.speed = speed;
    }
    
    @Override
    public void onUpdate(double tpf) {
        entity.translate(direction.multiply(speed * tpf));
        
        // Check if projectile is out of bounds
        if (entity.getX() < 0 || entity.getX() > 3 * 1024 || 
            entity.getY() < 0 || entity.getY() > 3 * 768) {
            entity.removeFromWorld();
        }
    }
}