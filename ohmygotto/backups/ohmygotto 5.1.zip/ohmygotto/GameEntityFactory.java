package com.ohmygotto;

import com.almasb.fxgl.dsl.EntityBuilder;
import com.almasb.fxgl.dsl.FXGL;
import com.almasb.fxgl.entity.Entity;
import com.almasb.fxgl.entity.EntityFactory;
import com.almasb.fxgl.entity.SpawnData;
import com.almasb.fxgl.entity.Spawns;
import com.almasb.fxgl.entity.components.CollidableComponent;
import com.almasb.fxgl.entity.components.IrremovableComponent;
import com.ohmygotto.TacticalSurvivors.EntityType;

import javafx.geometry.Point2D;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

public class GameEntityFactory implements EntityFactory {
    
    @Spawns("player")
    public Entity spawnPlayer(SpawnData data) {
        return FXGL.entityBuilder(data)
            .type(EntityType.PLAYER)
            .viewWithBBox(new Rectangle(30, 30, Color.BLUE))
            .with(new CollidableComponent(true))
            .build();
    }
    
    @Spawns("enemy")
    public Entity spawnEnemy(SpawnData data) {
        return FXGL.entityBuilder(data)
            .type(EntityType.ENEMY)
            .viewWithBBox(new Rectangle(25, 25, Color.RED))
            .with(new CollidableComponent(true))
            .build();
    }

    @Spawns("gridLine")
    public Entity spawnGridLine(SpawnData data) {
        // Add null checks and default values
        int width = data.get("width");
        int height = data.get("height");
        
        return FXGL.entityBuilder(data)
            .type(EntityType.GRID_LINE)
            .view(new Rectangle(width, height, Color.rgb(0, 0, 255, 0.3))) // Semi-transparent blue
            .zIndex(-50)
            .with(new IrremovableComponent())
            .build();
    }
    
    @Spawns("weapon")
    public Entity spawnWeapon(SpawnData data) {
        String weaponType = data.get("weaponType");
        Point2D direction = data.hasKey("direction") ? data.get("direction") : null;
        double speed = data.hasKey("speed") ? data.get("speed") : 0;
    
        EntityBuilder weapon = FXGL.entityBuilder(data)
            .type(TacticalSurvivors.EntityType.WEAPON)
            .with(new CollidableComponent(true))
            .with("weaponType", weaponType);
    
        switch (weaponType) {
            case "HG":
                weapon.viewWithBBox(new Rectangle(5, 5, Color.YELLOW));
                break;
            case "SG":
                weapon.viewWithBBox(new Rectangle(8, 8, Color.ORANGE));
                break;
            case "Assault Rifle":
                weapon.viewWithBBox(new Rectangle(8, 4, Color.LIGHTYELLOW));
                break;
            case "Sniper Rifle":
                weapon.viewWithBBox(new Rectangle(15, 3, Color.WHITESMOKE));
                break;
            case "Grenade":
                weapon.viewWithBBox(new Rectangle(12, 12, Color.DARKGREEN));
                break;
            case "FT":
                weapon.viewWithBBox(new Rectangle(8, 8, Color.ORANGERED));
                break;
            case "Rocket Launcher":
                weapon.viewWithBBox(new Rectangle(20, 8, Color.DARKGRAY));
                break;
            default:
                weapon.viewWithBBox(new Rectangle(10, 10, Color.WHITE));
        }
    
        if (direction != null) {
            Entity projectileEntity = weapon.build();
            projectileEntity.addComponent(new ProjectileComponent(direction, speed));
        
            // Despawn fallback
            FXGL.runOnce(() -> {
                if (projectileEntity.isActive()) {
                    projectileEntity.removeFromWorld();
                    System.out.println("Despawning: " + projectileEntity);
                }
            }, Duration.seconds(3)); // lifespan
        
            return projectileEntity;
        }
        
    
        if (data.hasKey("lifespan")) {
            double lifespan = data.get("lifespan");
            Entity builtWeapon = weapon.build();
            FXGL.runOnce(() -> {
                if (builtWeapon.isActive()) builtWeapon.removeFromWorld();
            }, Duration.seconds(lifespan));
            return builtWeapon;
        }
    
        return weapon.build();
    }
    
    
    @Spawns("experience")
    public Entity spawnExperience(SpawnData data) {
        return FXGL.entityBuilder(data)
            .type(TacticalSurvivors.EntityType.EXPERIENCE)
            .viewWithBBox(new Rectangle(10, 10, Color.GREEN))
            .with(new CollidableComponent(true))
            .build();
    }
    
    @Spawns("border")
    public Entity spawnBorder(SpawnData data) {
        int width = data.get("width");
        int height = data.get("height");
        
        return FXGL.entityBuilder(data)
            .type(TacticalSurvivors.EntityType.BORDER)
            .viewWithBBox(new Rectangle(width, height, Color.DARKRED))
            .with(new CollidableComponent(true))
            .build();
    }

    @Spawns("explosive")
    public Entity spawnExplosive(SpawnData data) {
        Point2D direction = data.get("direction");
        double speed = data.get("speed");
        double damage = data.get("damage");
        double range = data.hasKey("range") ? data.get("range") : 1.5;
        String type = data.get("weaponType");

        Entity projectile = FXGL.entityBuilder(data)
            .type(TacticalSurvivors.EntityType.WEAPON)
            .viewWithBBox(new Circle(8, Color.DARKRED))
            .with(new CollidableComponent(true))
            .with("weaponType", type)
            .with("damage", damage)
            .build();

        projectile.addComponent(new ProjectileComponent(direction, speed));

        // Manually trigger AoE after delay (simulate fuse)
        FXGL.runOnce(() -> {
            if (projectile.isActive()) {
                createExplosion(projectile.getCenter(), damage);
                projectile.removeFromWorld();
            }
        }, Duration.seconds(range));

        return projectile;
    }

    private void createExplosion(Point2D center, double damage) {
    FXGL.getGameWorld().getEntitiesByType(TacticalSurvivors.EntityType.ENEMY).forEach(enemy -> {
        if (enemy.getCenter().distance(center) < 100) {
            int hp = enemy.getInt("hp") - (int) damage;
            if (hp <= 0) enemy.removeFromWorld();
            else enemy.setProperty("hp", hp);
        }
    });

    // ✅ Create a proper FXGL entity with a circle view
    FXGL.spawn("explosionEffect", new SpawnData(center.getX() - 50, center.getY() - 50));
}


    @Spawns("explosionEffect")
    public Entity spawnExplosionEffect(SpawnData data) {
        // Create a filled circle with stroke to simulate explosion
        Circle fx = new Circle(100, Color.rgb(255, 100, 0, 0.4));
        fx.setStroke(Color.ORANGERED);
        fx.setStrokeWidth(2);
        
        // IMPORTANT: Set exact position here
        // fx.setTranslateX(0);
        // fx.setTranslateY(0);

        Entity explosion = FXGL.entityBuilder()
            .at(data.getX(), data.getY())
            .view(fx)
            .zIndex(500) // ensure it's on top
            .build();

        System.out.println("Spawning visual explosion entity at: " + data.getX() + ", " + data.getY());


        FXGL.getGameWorld().addEntity(explosion);
        FXGL.runOnce(explosion::removeFromWorld, Duration.seconds(0.4));

        return explosion;
    }

    @Spawns("railbeam")
    public Entity spawnRailBeam(SpawnData data) {
        Point2D origin = new Point2D(data.getX(), data.getY());
        Point2D direction = data.get("direction");
        double damage = data.get("damage");

        Point2D end = origin.add(direction.multiply(1600));

        Line beamLine = new Line(origin.getX(), origin.getY(), end.getX(), end.getY());
        beamLine.setStroke(Color.CYAN);
        beamLine.setStrokeWidth(4);
        beamLine.setOpacity(0.9);

        Entity beam = FXGL.entityBuilder()
            .view(beamLine)
            .zIndex(1000)
            .build();

        FXGL.getGameWorld().addEntity(beam);
        FXGL.runOnce(beam::removeFromWorld, Duration.seconds(0.2));

        // Damage logic
        FXGL.getGameWorld().getEntitiesByType(TacticalSurvivors.EntityType.ENEMY).forEach(enemy -> {
            Point2D enemyPos = enemy.getCenter();
            Point2D v = enemyPos.subtract(origin);
            double projection = v.dotProduct(direction);

            if (projection >= 0 && projection <= 1600) {
                Point2D closest = origin.add(direction.multiply(projection));
                if (enemyPos.distance(closest) < 20) {
                    int hp = enemy.getInt("hp") - (int) damage;
                    if (hp <= 0) enemy.removeFromWorld();
                    else enemy.setProperty("hp", hp);
                }
            }
        });

        return beam;
    }



}