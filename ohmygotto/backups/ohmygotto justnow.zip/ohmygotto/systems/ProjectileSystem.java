package com.ohmygotto.systems;

import com.almasb.fxgl.dsl.FXGL;
import com.almasb.fxgl.entity.SpawnData;
import com.ohmygotto.Weapon;

import javafx.geometry.Point2D;
import javafx.util.Duration;

public class ProjectileSystem {
    private static final ProjectileSystem instance = new ProjectileSystem();
    
    public static ProjectileSystem getInstance() { return instance; }
    
    public void createProjectile(Weapon weapon, Point2D origin, Point2D direction) {
        switch (weapon.id) {
            case "SG":
                createShotgunSpread(weapon, origin, direction);
                break;
            case "SR":
                createSniperShot(weapon, origin, direction);
                break;
            // ... pota masadotakon
            case "SMG":
                createSMGShot(weapon, origin, direction);
                break;
        }
        FXGL.play("shoot.wav");
    }
    
    private void createShotgunSpread(Weapon weapon, Point2D origin, Point2D direction) {
        for (int i = -2; i <= 2; i++) {
            double angle = Math.atan2(direction.getY(), direction.getX()) + Math.toRadians(i * 10);
            Point2D spread = new Point2D(Math.cos(angle), Math.sin(angle));
            FXGL.spawn("weapon", 
                new SpawnData(origin.getX(), origin.getY())
                    .put("direction", spread)
                    .put("weaponType", weapon.id)
                    .put("damage", weapon.damage));
        }
    }

    private void createSMGShot(Weapon weapon, Point2D origin, Point2D direction) {
        for (int i = 0; i < 3; i++) {
            FXGL.runOnce(() -> {
                Point2D accuracy = direction.add(Math.random() * 0.1 - 0.05, Math.random() * 0.1 - 0.05).normalize();
                FXGL.spawn("weapon", 
                new SpawnData(origin.getX(), origin.getY())
                    .put("direction", accuracy)
                    .put("weaponType", weapon.id)
                    .put("damage", weapon.damage));
            }, Duration.millis(i * 50));
        }
    }

    private void createMachineGun(Weapon weapon, Point2D origin, Point2D direction) {
        Point2D accuracy = direction.add(Math.random() * 0.3 - 0.1, Math.random() * 0.3 - 0.1).normalize();
        FXGL.spawn("weapon", 
                new SpawnData(origin.getX(), origin.getY())
                    .put("direction", accuracy)
                    .put("weaponType", weapon.id)
                    .put("damage", weapon.damage));
    }

    private void createSniperShot(Weapon weapon, Point2D origin, Point2D direction) {
        FXGL.spawn("weapon", new SpawnData(origin.getX(), origin.getY())
            .put("direction", direction)
            .put("speed", 900.0)
            .put("weaponType", weapon.id)
            .put("damage", weapon.damage));
    }
}