package com.ohmygotto.systems;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.almasb.fxgl.dsl.FXGL;
import com.ohmygotto.GameState;
import com.ohmygotto.Weapon;

import javafx.geometry.Point2D;
import javafx.scene.paint.Color;
import javafx.util.Duration;

public class WeaponSystem {
    private final Map<String, Weapon> unlockedWeapons = new HashMap<>();
    private Weapon currentWeapon;
    private Weapon nextWeapon;
    
    public void init() {
        List<String> weaponIds = List.of("SG", "SMG", "AR", "GL", "HG", "SR", "RG", "MG", "RL", "MT", "FT");
        weaponIds.forEach(id -> unlockedWeapons.put(id, createWeapon(id)));
        
        currentWeapon = unlockedWeapons.get("SG"); // Default weapon
    }
    
    private Weapon createWeapon(String id) {
        double fireRateMod = GameState.getInstance().getPlayerFireRate();
        double dmgMod = GameState.getInstance().getPlayerDamageBoost();
        
        switch (id) {
            case "SG": return new Weapon(id, 6, 6, 1000 * fireRateMod, 4 + dmgMod, 1.5);
            case "SMG": return new Weapon(id, 30, 30, 500 * fireRateMod, 2 + dmgMod, 1.2);
            case "AR": return new Weapon(id, 20, 20, 250 * fireRateMod, 3 + dmgMod, 2.0);
            case "GL": return new Weapon(id, 3, 3, 1200 * fireRateMod, 8 + dmgMod, 1.8);
            case "HG": return new Weapon(id, 12, 12, 400 * fireRateMod, 2.5 + dmgMod, 1.5);
            case "SR": return new Weapon(id, 5, 5, 1500 * fireRateMod, 15 + dmgMod, 2.8);
            case "RG": return new Weapon(id, 3, 3, 2000 * fireRateMod, 12 + dmgMod, 3.0);
            case "MG": return new Weapon(id, 60, 60, 100 * fireRateMod, 1.8 + dmgMod, 1.0);
            case "RL": return new Weapon(id, 2, 2, 2000 * fireRateMod, 10 + dmgMod, 1.5);
            case "MT": return new Weapon(id, 1, 1, 3000 * fireRateMod, 25 + dmgMod, 2.5);
            case "FT": return new Weapon(id, 50, 50, 100 * fireRateMod, 0.8 + dmgMod, 0.6);
            // default: return new Weapon(id, 10, 10, 500 * playfireRateModerFireRate, 3 + dmgMod, 1.5);
            default : throw new IllegalArgumentException("Unknown weapon: " + id);
        }
    }
    
    public void fire(Point2D origin, Point2D direction) {
        if (currentWeapon == null || !currentWeapon.canFire());
        
        // Delegate to projectile system
        ProjectileSystem.getInstance().createProjectile(
            currentWeapon, 
            origin, 
            direction
        );
        
        currentWeapon.ammo--;
        if (currentWeapon.ammo <= 0) {
            startReload();
        }
    }
    
    private void startReload() {
        List<Weapon> pool = new ArrayList<>(unlockedWeapons.values());
        if (pool.size() > 1) pool.remove(currentWeapon);
        nextWeapon = pool.get(new Random().nextInt(pool.size()));
        
        FXGL.runOnce(() -> {
            currentWeapon = nextWeapon;
            currentWeapon.reload();
            nextWeapon = null;
        }, Duration.seconds(1));
    }
    
    // General Getters
    public Weapon getCurrentWeapon() {
        return currentWeapon;
    }

    public Weapon getNextWeapon() {
        return nextWeapon;
    }

    // UI Getters
    public String getCurrentWeaponDisplay() {
        return currentWeapon != null ? currentWeapon.getDisplayName() : "No Weapon";
    }

    public String getAmmoStatus() {
        if (currentWeapon == null) return "0/0";
        return String.format("%d/%d", currentWeapon.ammo, currentWeapon.maxAmmo);
    }

    public String getNextWeaponDisplay() {
        return nextWeapon != null ? nextWeapon.getDisplayName() : "-";
    }

    public double getReloadProgress() {
        // Optional: For reload progress bars
        return currentWeapon != null ? 
            (double)currentWeapon.ammo / currentWeapon.maxAmmo : 0;
    }

    public Color getAmmoColor() {
        if (currentWeapon == null) return Color.GRAY;
        
        double ratio = (double)currentWeapon.ammo / currentWeapon.maxAmmo;
        if (ratio <= 0.25) return Color.RED;
        if (ratio <= 0.5) return Color.ORANGE;
        return Color.YELLOW;
    }
}